blogs=[
   {
       title:"Getting started with Python",
       content:"This is content of Python",
       courseDetails:"It has 4 lectures",
       duration: "4 weeks course", 
       slug:"learn-python"
   },
   {
    title:"Getting started with Java",
    content:"This is content of Java",
    courseDetails:"It has 6 lectures",
    duration: "5 weeks course", 
    slug:"learn-java"
  },
  {
    title:"Getting started with Php",
    content:"This is content of Php",
    courseDetails:"It has 3 lectures",
    duration: "4 weeks course", 
    slug:"learn-php"
  },
  {
    title:"Getting started with C++",
    content:"This is content of C++",
    courseDetails:"It has 9 lectures",
    duration: "9 weeks course", 
    slug:"learn-C++"
  }

]
module.exports=blogs;